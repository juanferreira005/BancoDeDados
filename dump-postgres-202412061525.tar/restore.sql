--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: animais; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.animais (
    animalid integer NOT NULL,
    nome character varying(50) NOT NULL,
    especie character varying(30) NOT NULL,
    raca character varying(50),
    idade integer,
    clienteid integer NOT NULL
);


ALTER TABLE public.animais OWNER TO postgres;

--
-- Name: atendimentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.atendimentos (
    atendimentoid integer NOT NULL,
    animalid integer NOT NULL,
    servicoid integer NOT NULL,
    dataatendimento date DEFAULT CURRENT_DATE,
    observacoes text
);


ALTER TABLE public.atendimentos OWNER TO postgres;

--
-- Name: clientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clientes (
    clienteid integer NOT NULL,
    nome character varying(100) NOT NULL,
    telefone character varying(15),
    email character varying(100),
    endereco text
);


ALTER TABLE public.clientes OWNER TO postgres;

--
-- Name: produtos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produtos (
    produtoid integer NOT NULL,
    nome character varying(50) NOT NULL,
    descricao text,
    preco numeric(10,2) NOT NULL,
    estoque integer NOT NULL
);


ALTER TABLE public.produtos OWNER TO postgres;

--
-- Name: servicos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.servicos (
    servicoid integer NOT NULL,
    nome character varying(50) NOT NULL,
    descricao text,
    preco numeric(10,2) NOT NULL
);


ALTER TABLE public.servicos OWNER TO postgres;

--
-- Data for Name: animais; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.animais (animalid, nome, especie, raca, idade, clienteid) FROM stdin;
\.
COPY public.animais (animalid, nome, especie, raca, idade, clienteid) FROM '$$PATH$$/4891.dat';

--
-- Data for Name: atendimentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.atendimentos (atendimentoid, animalid, servicoid, dataatendimento, observacoes) FROM stdin;
\.
COPY public.atendimentos (atendimentoid, animalid, servicoid, dataatendimento, observacoes) FROM '$$PATH$$/4893.dat';

--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clientes (clienteid, nome, telefone, email, endereco) FROM stdin;
\.
COPY public.clientes (clienteid, nome, telefone, email, endereco) FROM '$$PATH$$/4890.dat';

--
-- Data for Name: produtos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produtos (produtoid, nome, descricao, preco, estoque) FROM stdin;
\.
COPY public.produtos (produtoid, nome, descricao, preco, estoque) FROM '$$PATH$$/4894.dat';

--
-- Data for Name: servicos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.servicos (servicoid, nome, descricao, preco) FROM stdin;
\.
COPY public.servicos (servicoid, nome, descricao, preco) FROM '$$PATH$$/4892.dat';

--
-- Name: animais animais_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.animais
    ADD CONSTRAINT animais_pkey PRIMARY KEY (animalid);


--
-- Name: atendimentos atendimentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atendimentos
    ADD CONSTRAINT atendimentos_pkey PRIMARY KEY (atendimentoid);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (clienteid);


--
-- Name: produtos produtos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT produtos_pkey PRIMARY KEY (produtoid);


--
-- Name: servicos servicos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servicos
    ADD CONSTRAINT servicos_pkey PRIMARY KEY (servicoid);


--
-- Name: animais animais_clienteid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.animais
    ADD CONSTRAINT animais_clienteid_fkey FOREIGN KEY (clienteid) REFERENCES public.clientes(clienteid);


--
-- Name: atendimentos atendimentos_animalid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atendimentos
    ADD CONSTRAINT atendimentos_animalid_fkey FOREIGN KEY (animalid) REFERENCES public.animais(animalid);


--
-- Name: atendimentos atendimentos_servicoid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.atendimentos
    ADD CONSTRAINT atendimentos_servicoid_fkey FOREIGN KEY (servicoid) REFERENCES public.servicos(servicoid);


--
-- PostgreSQL database dump complete
--

